from .interfaces import WMLightAuthInterface, ApiInterface
